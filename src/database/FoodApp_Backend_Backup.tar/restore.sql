--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "FoodApp_Backend";
--
-- Name: FoodApp_Backend; Type: DATABASE; Schema: -; Owner: main
--

CREATE DATABASE "FoodApp_Backend" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'es_VE.UTF-8';


ALTER DATABASE "FoodApp_Backend" OWNER TO main;

\connect "FoodApp_Backend"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    photo character varying(255)
);


ALTER TABLE public.categories OWNER TO main;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO main;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.categories.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.favorites (
    user_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.favorites OWNER TO main;

--
-- Name: populars; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.populars (
    id integer NOT NULL,
    product_id integer
);


ALTER TABLE public.populars OWNER TO main;

--
-- Name: populars_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.populars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.populars_id_seq OWNER TO main;

--
-- Name: populars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.populars_id_seq OWNED BY public.populars.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    price real NOT NULL,
    total_price real NOT NULL,
    photo character varying(255),
    incart boolean DEFAULT false NOT NULL,
    counter integer DEFAULT 0 NOT NULL,
    category_id integer
);


ALTER TABLE public.products OWNER TO main;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO main;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: main
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    profileimage character varying(200),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO main;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: main
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO main;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: main
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: populars id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.populars ALTER COLUMN id SET DEFAULT nextval('public.populars_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.categories (id, name, photo) FROM stdin;
\.
COPY public.categories (id, name, photo) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.favorites (user_id, product_id) FROM stdin;
\.
COPY public.favorites (user_id, product_id) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: populars; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.populars (id, product_id) FROM stdin;
\.
COPY public.populars (id, product_id) FROM '$$PATH$$/3431.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.products (id, name, description, price, total_price, photo, incart, counter, category_id) FROM stdin;
\.
COPY public.products (id, name, description, price, total_price, photo, incart, counter, category_id) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: main
--

COPY public.users (id, username, email, firstname, lastname, password, profileimage, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.users (id, username, email, firstname, lastname, password, profileimage, "createdAt", "updatedAt") FROM '$$PATH$$/3435.dat';

--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: populars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.populars_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: main
--

SELECT pg_catalog.setval('public.users_id_seq', 12, true);


--
-- Name: categories departments_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (user_id, product_id);


--
-- Name: populars populars_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.populars
    ADD CONSTRAINT populars_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: populars populars_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.populars
    ADD CONSTRAINT populars_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: main
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- PostgreSQL database dump complete
--

